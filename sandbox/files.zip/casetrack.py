#!/usr/bin/env python3
"""
casetrack - Manifest-centric case management for bioinformatics pipelines.

Every analysis appends columns to a single manifest TSV, creating a growing
record of what's been computed for each sample. Built for HPC/SLURM environments
with file locking for concurrent job safety.

Usage:
    casetrack init      --manifest manifest.tsv --samples samples.txt [--cols col1,col2]
    casetrack append    --manifest manifest.tsv --results result.tsv --key sample_id --analysis modkit
    casetrack status    --manifest manifest.tsv [--analysis modkit] [--fmt table|tsv|json]
    casetrack validate  --manifest manifest.tsv --key sample_id
    casetrack log       --manifest manifest.tsv [--last N]
    casetrack schema    --manifest manifest.tsv [--fmt table|json]
    casetrack export    --manifest manifest.tsv --output out.xlsx

Author: Samuel Ahuno (sahuno)
"""

import argparse
import datetime
import fcntl
import json
import os
import sys
import hashlib
from pathlib import Path

try:
    import pandas as pd
except ImportError:
    print("Error: pandas is required. Install with: pip install pandas", file=sys.stderr)
    sys.exit(1)


# ── Constants ──────────────────────────────────────────────────────────────────

PROVENANCE_SUFFIX = ".provenance.jsonl"
LOCK_SUFFIX = ".lock"
SCHEMA_SUFFIX = ".schema.json"

DONE_COLUMN_SUFFIX = "_done"
TIMESTAMP_FMT = "%Y-%m-%dT%H:%M:%S"


# ── File Locking ───────────────────────────────────────────────────────────────

class ManifestLock:
    """Context manager for file-level locking. Safe for concurrent SLURM jobs."""

    def __init__(self, manifest_path: str, timeout: int = 300):
        self.lock_path = manifest_path + LOCK_SUFFIX
        self.timeout = timeout
        self._lockfile = None

    def __enter__(self):
        self._lockfile = open(self.lock_path, "w")
        try:
            fcntl.flock(self._lockfile, fcntl.LOCK_EX)
        except OSError as e:
            self._lockfile.close()
            raise RuntimeError(
                f"Could not acquire lock on {self.lock_path}: {e}\n"
                f"If a previous job crashed, remove the lock file manually."
            ) from e
        return self

    def __exit__(self, *args):
        if self._lockfile:
            fcntl.flock(self._lockfile, fcntl.LOCK_UN)
            self._lockfile.close()


# ── Provenance Logging ─────────────────────────────────────────────────────────

def log_provenance(manifest_path: str, entry: dict):
    """Append a provenance record as a JSONL line."""
    log_path = manifest_path + PROVENANCE_SUFFIX
    entry["timestamp"] = datetime.datetime.now().strftime(TIMESTAMP_FMT)
    entry["user"] = os.environ.get("USER", "unknown")
    entry["hostname"] = os.environ.get("HOSTNAME", "unknown")
    entry["slurm_job_id"] = os.environ.get("SLURM_JOB_ID", None)
    entry["slurm_array_task_id"] = os.environ.get("SLURM_ARRAY_TASK_ID", None)

    with open(log_path, "a") as f:
        f.write(json.dumps(entry, default=str) + "\n")


def _checksum(filepath: str) -> str:
    """Quick MD5 checksum of a file for provenance tracking."""
    h = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


# ── Schema Tracking ────────────────────────────────────────────────────────────

def update_schema(manifest_path: str, analysis: str, new_columns: list):
    """Track which analysis added which columns."""
    schema_path = manifest_path + SCHEMA_SUFFIX
    schema = {}
    if os.path.exists(schema_path):
        with open(schema_path) as f:
            schema = json.load(f)

    schema[analysis] = {
        "columns": new_columns,
        "added": datetime.datetime.now().strftime(TIMESTAMP_FMT),
        "added_by": os.environ.get("USER", "unknown"),
    }

    with open(schema_path, "w") as f:
        json.dump(schema, f, indent=2)


# ── Core Commands ──────────────────────────────────────────────────────────────

def cmd_init(args):
    """Initialize a new manifest from a sample list."""
    manifest_path = args.manifest

    if os.path.exists(manifest_path) and not args.force:
        print(f"Error: {manifest_path} already exists. Use --force to overwrite.", file=sys.stderr)
        sys.exit(1)

    # Read sample IDs
    samples_path = args.samples
    if not os.path.exists(samples_path):
        print(f"Error: samples file not found: {samples_path}", file=sys.stderr)
        sys.exit(1)

    with open(samples_path) as f:
        sample_ids = [line.strip() for line in f if line.strip() and not line.startswith("#")]

    if not sample_ids:
        print("Error: no sample IDs found in samples file.", file=sys.stderr)
        sys.exit(1)

    # Build initial manifest
    key_col = args.key
    df = pd.DataFrame({key_col: sample_ids})

    # Add optional extra columns from a metadata TSV
    if args.metadata:
        if not os.path.exists(args.metadata):
            print(f"Error: metadata file not found: {args.metadata}", file=sys.stderr)
            sys.exit(1)
        meta = pd.read_csv(args.metadata, sep="\t")
        if key_col not in meta.columns:
            print(f"Error: key column '{key_col}' not found in metadata file.", file=sys.stderr)
            sys.exit(1)
        df = df.merge(meta, on=key_col, how="left")

    # Add optional bare columns
    if args.cols:
        for col in args.cols.split(","):
            col = col.strip()
            if col and col not in df.columns:
                df[col] = pd.NA

    df.to_csv(manifest_path, sep="\t", index=False)

    log_provenance(manifest_path, {
        "action": "init",
        "samples_file": str(samples_path),
        "n_samples": len(sample_ids),
        "columns": list(df.columns),
    })

    print(f"Initialized {manifest_path} with {len(sample_ids)} samples, {len(df.columns)} columns.")


def cmd_append(args):
    """Append analysis results as new columns to the manifest."""
    manifest_path = args.manifest
    results_path = args.results
    key_col = args.key
    analysis = args.analysis

    if not os.path.exists(manifest_path):
        print(f"Error: manifest not found: {manifest_path}", file=sys.stderr)
        sys.exit(1)

    if not os.path.exists(results_path):
        print(f"Error: results file not found: {results_path}", file=sys.stderr)
        sys.exit(1)

    # Read results
    results = pd.read_csv(results_path, sep="\t")
    if key_col not in results.columns:
        print(f"Error: key column '{key_col}' not in results file. Columns: {list(results.columns)}", file=sys.stderr)
        sys.exit(1)

    # Determine new columns (everything except the key)
    new_cols = [c for c in results.columns if c != key_col]
    if not new_cols:
        print("Error: results file has no columns besides the key.", file=sys.stderr)
        sys.exit(1)

    # Add a _done timestamp column if not already present
    done_col = f"{analysis}{DONE_COLUMN_SUFFIX}"
    if done_col not in results.columns:
        results[done_col] = datetime.datetime.now().strftime("%Y-%m-%d")
        new_cols.append(done_col)

    # Lock and merge
    with ManifestLock(manifest_path):
        manifest = pd.read_csv(manifest_path, sep="\t")

        if key_col not in manifest.columns:
            print(f"Error: key column '{key_col}' not in manifest. Columns: {list(manifest.columns)}", file=sys.stderr)
            sys.exit(1)

        # Check for unrecognized sample IDs
        result_keys = set(results[key_col].astype(str))
        manifest_keys = set(manifest[key_col].astype(str))
        unknown = result_keys - manifest_keys
        if unknown and not args.allow_new:
            print(
                f"Warning: {len(unknown)} sample(s) in results not in manifest: {sorted(unknown)[:5]}...\n"
                f"Use --allow-new to add them as new rows.",
                file=sys.stderr,
            )

        # Check for column collisions
        existing_cols = set(manifest.columns)
        collisions = [c for c in new_cols if c in existing_cols]
        if collisions:
            # Smart merge: if the columns already exist, update only the NaN cells
            # This is the common case for per-sample SLURM array jobs where
            # the first job creates the columns and subsequent jobs fill in rows.
            if args.overwrite:
                manifest = manifest.drop(columns=collisions)
                print(f"Overwriting existing columns: {collisions}", file=sys.stderr)
                how = "outer" if args.allow_new else "left"
                merged = manifest.merge(results, on=key_col, how=how)
            else:
                # Update-in-place: fill NaN cells with new values
                results_indexed = results.set_index(key_col)
                merged = manifest.copy()
                for col in collisions:
                    if col in results_indexed.columns:
                        for idx, row in merged.iterrows():
                            key_val = str(row[key_col])
                            if key_val in results_indexed.index and pd.isna(row[col]):
                                merged.at[idx, col] = results_indexed.loc[key_val, col]
                # Add any truly new columns
                new_only = [c for c in new_cols if c not in existing_cols]
                if new_only:
                    results_new = results[[key_col] + new_only]
                    how = "outer" if args.allow_new else "left"
                    merged = merged.merge(results_new, on=key_col, how=how)
        else:
            # No collisions — simple merge
            how = "outer" if args.allow_new else "left"
            merged = manifest.merge(results, on=key_col, how=how)

        # Write back
        merged.to_csv(manifest_path, sep="\t", index=False)

    # Update schema and provenance
    update_schema(manifest_path, analysis, new_cols)

    samples_updated = len(result_keys & manifest_keys)
    log_provenance(manifest_path, {
        "action": "append",
        "analysis": analysis,
        "results_file": str(results_path),
        "results_checksum": _checksum(results_path),
        "columns_added": new_cols,
        "samples_updated": samples_updated,
        "samples_new": len(unknown) if args.allow_new else 0,
    })

    print(f"Appended {len(new_cols)} columns from '{analysis}' for {samples_updated} samples.")


def cmd_status(args):
    """Show completion status across analyses."""
    manifest_path = args.manifest

    if not os.path.exists(manifest_path):
        print(f"Error: manifest not found: {manifest_path}", file=sys.stderr)
        sys.exit(1)

    manifest = pd.read_csv(manifest_path, sep="\t")

    # Find all _done columns
    done_cols = [c for c in manifest.columns if c.endswith(DONE_COLUMN_SUFFIX)]

    if args.analysis:
        target = f"{args.analysis}{DONE_COLUMN_SUFFIX}"
        if target in done_cols:
            done_cols = [target]
        else:
            print(f"No _done column found for analysis '{args.analysis}'.", file=sys.stderr)
            sys.exit(1)

    key_col = args.key
    if key_col not in manifest.columns:
        # Try to guess the key column (first column)
        key_col = manifest.columns[0]

    n_samples = len(manifest)

    if args.fmt == "json":
        status = {}
        for dc in done_cols:
            analysis_name = dc.replace(DONE_COLUMN_SUFFIX, "")
            completed = int(manifest[dc].notna().sum())
            status[analysis_name] = {
                "completed": completed,
                "total": n_samples,
                "pct": round(100 * completed / n_samples, 1) if n_samples > 0 else 0,
                "missing": sorted(manifest.loc[manifest[dc].isna(), key_col].tolist()),
            }
        print(json.dumps(status, indent=2, default=str))
    elif args.fmt == "tsv":
        print("analysis\tcompleted\ttotal\tpct")
        for dc in done_cols:
            analysis_name = dc.replace(DONE_COLUMN_SUFFIX, "")
            completed = int(manifest[dc].notna().sum())
            pct = round(100 * completed / n_samples, 1) if n_samples > 0 else 0
            print(f"{analysis_name}\t{completed}\t{n_samples}\t{pct}")
    else:
        # Table format
        print(f"\nManifest: {manifest_path}")
        print(f"Samples:  {n_samples}")
        print(f"Columns:  {len(manifest.columns)}")
        print(f"{'─' * 55}")
        print(f"{'Analysis':<30} {'Done':>6} {'Total':>6} {'%':>7}")
        print(f"{'─' * 55}")
        for dc in done_cols:
            analysis_name = dc.replace(DONE_COLUMN_SUFFIX, "")
            completed = int(manifest[dc].notna().sum())
            pct = round(100 * completed / n_samples, 1) if n_samples > 0 else 0
            bar_len = 10
            filled = int(bar_len * pct / 100)
            bar = "█" * filled + "░" * (bar_len - filled)
            print(f"{analysis_name:<30} {completed:>6} {n_samples:>6} {pct:>6.1f}% {bar}")
        print(f"{'─' * 55}")

        # Show incomplete samples if few
        for dc in done_cols:
            missing = manifest.loc[manifest[dc].isna(), key_col].tolist()
            if 0 < len(missing) <= 5:
                analysis_name = dc.replace(DONE_COLUMN_SUFFIX, "")
                print(f"\n  Missing for {analysis_name}: {', '.join(str(s) for s in missing)}")


def cmd_validate(args):
    """Validate manifest integrity."""
    manifest_path = args.manifest
    key_col = args.key

    if not os.path.exists(manifest_path):
        print(f"Error: manifest not found: {manifest_path}", file=sys.stderr)
        sys.exit(1)

    manifest = pd.read_csv(manifest_path, sep="\t")
    issues = []

    # Check key column exists
    if key_col not in manifest.columns:
        issues.append(f"Key column '{key_col}' not found. Columns: {list(manifest.columns)}")
    else:
        # Check for duplicate keys
        dupes = manifest[manifest[key_col].duplicated(keep=False)]
        if not dupes.empty:
            dupe_ids = sorted(dupes[key_col].unique().tolist())
            issues.append(f"Duplicate sample IDs: {dupe_ids[:10]}")

        # Check for null keys
        null_keys = manifest[key_col].isna().sum()
        if null_keys > 0:
            issues.append(f"{null_keys} rows with null sample IDs")

    # Check for completely empty columns
    empty_cols = [c for c in manifest.columns if manifest[c].isna().all()]
    if empty_cols:
        issues.append(f"Completely empty columns: {empty_cols}")

    # Check schema consistency and _done column integrity
    schema_path = manifest_path + SCHEMA_SUFFIX
    schema = {}
    if os.path.exists(schema_path):
        with open(schema_path) as f:
            schema = json.load(f)
        for analysis, info in schema.items():
            for col in info.get("columns", []):
                if col not in manifest.columns:
                    issues.append(f"Schema says '{col}' should exist (from '{analysis}') but it's missing")

    done_cols = [c for c in manifest.columns if c.endswith(DONE_COLUMN_SUFFIX)]
    for dc in done_cols:
        analysis_name = dc.replace(DONE_COLUMN_SUFFIX, "")
        # Use schema to find related columns if available
        if analysis_name in schema:
            data_cols = [c for c in schema[analysis_name].get("columns", []) if c != dc]
            if not data_cols:
                issues.append(f"Done column '{dc}' has no data columns in schema")
        else:
            # Fallback: any non-key, non-done column with same prefix
            related = [c for c in manifest.columns if c.startswith(analysis_name) and c != dc]
            if not related:
                issues.append(f"Done column '{dc}' has no corresponding data columns and no schema entry")

    if issues:
        print(f"Validation found {len(issues)} issue(s):", file=sys.stderr)
        for i, issue in enumerate(issues, 1):
            print(f"  {i}. {issue}", file=sys.stderr)
        sys.exit(1)
    else:
        print(f"Manifest OK: {len(manifest)} samples, {len(manifest.columns)} columns, no issues.")


def cmd_log(args):
    """Show provenance log entries."""
    manifest_path = args.manifest
    log_path = manifest_path + PROVENANCE_SUFFIX

    if not os.path.exists(log_path):
        print("No provenance log found.", file=sys.stderr)
        sys.exit(1)

    with open(log_path) as f:
        lines = f.readlines()

    if args.last:
        lines = lines[-args.last:]

    for line in lines:
        entry = json.loads(line.strip())
        ts = entry.get("timestamp", "?")
        action = entry.get("action", "?")
        user = entry.get("user", "?")
        job = entry.get("slurm_job_id", "")
        analysis = entry.get("analysis", "")

        job_str = f" [SLURM {job}]" if job else ""
        analysis_str = f" ({analysis})" if analysis else ""

        if action == "init":
            n = entry.get("n_samples", "?")
            print(f"  {ts}  INIT  {user}{job_str} — {n} samples")
        elif action == "append":
            cols = entry.get("columns_added", [])
            n_updated = entry.get("samples_updated", "?")
            print(f"  {ts}  APPEND{analysis_str}  {user}{job_str} — {len(cols)} cols, {n_updated} samples")
        else:
            print(f"  {ts}  {action.upper()}  {user}{job_str}{analysis_str}")


def cmd_schema(args):
    """Show which analysis added which columns."""
    manifest_path = args.manifest
    schema_path = manifest_path + SCHEMA_SUFFIX

    if not os.path.exists(schema_path):
        print("No schema file found. Run 'casetrack append' to build one.", file=sys.stderr)
        sys.exit(1)

    with open(schema_path) as f:
        schema = json.load(f)

    if args.fmt == "json":
        print(json.dumps(schema, indent=2))
    else:
        print(f"\n{'Analysis':<25} {'Columns':<40} {'Added by':<12} {'Date'}")
        print(f"{'─' * 90}")
        for analysis, info in schema.items():
            cols = ", ".join(info.get("columns", []))
            added_by = info.get("added_by", "?")
            added = info.get("added", "?")
            print(f"{analysis:<25} {cols:<40} {added_by:<12} {added}")


def cmd_export(args):
    """Export manifest to other formats."""
    manifest_path = args.manifest
    output_path = args.output

    if not os.path.exists(manifest_path):
        print(f"Error: manifest not found: {manifest_path}", file=sys.stderr)
        sys.exit(1)

    manifest = pd.read_csv(manifest_path, sep="\t")
    ext = Path(output_path).suffix.lower()

    if ext == ".xlsx":
        try:
            manifest.to_excel(output_path, index=False, engine="openpyxl")
        except ImportError:
            print("Error: openpyxl required for Excel export. pip install openpyxl", file=sys.stderr)
            sys.exit(1)
    elif ext == ".csv":
        manifest.to_csv(output_path, index=False)
    elif ext == ".json":
        manifest.to_json(output_path, orient="records", indent=2)
    elif ext in (".parquet", ".pq"):
        try:
            manifest.to_parquet(output_path, index=False)
        except ImportError:
            print("Error: pyarrow required for Parquet export. pip install pyarrow", file=sys.stderr)
            sys.exit(1)
    else:
        print(f"Error: unsupported format '{ext}'. Use .xlsx, .csv, .json, or .parquet", file=sys.stderr)
        sys.exit(1)

    print(f"Exported {len(manifest)} samples to {output_path}")


# ── CLI Parser ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="casetrack",
        description="Manifest-centric case management for bioinformatics pipelines.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Initialize a new project manifest
  casetrack init --manifest manifest.tsv --samples samples.txt

  # Initialize with metadata columns
  casetrack init --manifest manifest.tsv --samples samples.txt --metadata sample_info.tsv

  # Append modkit results after a SLURM job
  casetrack append --manifest manifest.tsv --results modkit_summary.tsv \\
      --key sample_id --analysis modkit_methylation

  # Check what's done
  casetrack status --manifest manifest.tsv

  # Validate manifest integrity
  casetrack validate --manifest manifest.tsv --key sample_id

  # View provenance log
  casetrack log --manifest manifest.tsv --last 10

  # Export to Excel for sharing
  casetrack export --manifest manifest.tsv --output manifest.xlsx
        """,
    )
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # ── init ──
    p_init = subparsers.add_parser("init", help="Initialize a new manifest")
    p_init.add_argument("--manifest", required=True, help="Path to manifest TSV")
    p_init.add_argument("--samples", required=True, help="Text file with one sample_id per line")
    p_init.add_argument("--key", default="sample_id", help="Key column name (default: sample_id)")
    p_init.add_argument("--metadata", help="Optional TSV with additional sample metadata")
    p_init.add_argument("--cols", help="Comma-separated list of empty columns to pre-create")
    p_init.add_argument("--force", action="store_true", help="Overwrite existing manifest")

    # ── append ──
    p_append = subparsers.add_parser("append", help="Append analysis results to manifest")
    p_append.add_argument("--manifest", required=True, help="Path to manifest TSV")
    p_append.add_argument("--results", required=True, help="Path to results TSV")
    p_append.add_argument("--key", default="sample_id", help="Key column to join on (default: sample_id)")
    p_append.add_argument("--analysis", required=True, help="Name of this analysis (e.g. modkit_methylation)")
    p_append.add_argument("--overwrite", action="store_true", help="Overwrite existing columns")
    p_append.add_argument("--allow-new", action="store_true", help="Allow new sample IDs not in manifest")

    # ── status ──
    p_status = subparsers.add_parser("status", help="Show completion status")
    p_status.add_argument("--manifest", required=True, help="Path to manifest TSV")
    p_status.add_argument("--key", default="sample_id", help="Key column name")
    p_status.add_argument("--analysis", help="Filter to a specific analysis")
    p_status.add_argument("--fmt", choices=["table", "tsv", "json"], default="table", help="Output format")

    # ── validate ──
    p_validate = subparsers.add_parser("validate", help="Validate manifest integrity")
    p_validate.add_argument("--manifest", required=True, help="Path to manifest TSV")
    p_validate.add_argument("--key", default="sample_id", help="Key column name")

    # ── log ──
    p_log = subparsers.add_parser("log", help="Show provenance log")
    p_log.add_argument("--manifest", required=True, help="Path to manifest TSV")
    p_log.add_argument("--last", type=int, help="Show only the last N entries")

    # ── schema ──
    p_schema = subparsers.add_parser("schema", help="Show column-to-analysis mapping")
    p_schema.add_argument("--manifest", required=True, help="Path to manifest TSV")
    p_schema.add_argument("--fmt", choices=["table", "json"], default="table", help="Output format")

    # ── export ──
    p_export = subparsers.add_parser("export", help="Export manifest to other formats")
    p_export.add_argument("--manifest", required=True, help="Path to manifest TSV")
    p_export.add_argument("--output", required=True, help="Output path (.xlsx, .csv, .json, .parquet)")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    commands = {
        "init": cmd_init,
        "append": cmd_append,
        "status": cmd_status,
        "validate": cmd_validate,
        "log": cmd_log,
        "schema": cmd_schema,
        "export": cmd_export,
    }

    commands[args.command](args)


if __name__ == "__main__":
    main()
